<template>
    <section class="p-8 max-w-xl mx-auto">
      <h2 class="text-3xl font-bold mb-6">Entre em Contato</h2>
  
      <form class="space-y-4">
        <input type="text" placeholder="Seu nome" class="w-full p-3 border rounded" />
        <input type="email" placeholder="Seu e-mail" class="w-full p-3 border rounded" />
        <textarea placeholder="Sua mensagem" class="w-full p-3 border rounded h-32"></textarea>
        <button type="submit" class="bg-destaque text-white px-6 py-2 rounded hover:bg-blue-700">
          Enviar
        </button>
      </form>
  
      <div class="mt-8">
        <h3 class="text-xl font-semibold mb-2">Minhas redes sociais</h3>
        <ul class="space-y-2">
          <li>
            <a href="https://www.linkedin.com/in/felipe-meireles-2b83212b5/?originalSubdomain=br" class="text-blue-600 hover:underline">LinkedIn</a>
          </li>
          <li>
            <a href="https://github.com/F3lipeM3ireles" class="text-blue-600 hover:underline">GitHub</a>
          </li>
          <li>
            <a href="https://www.instagram.com/felps.idk/" class="text-blue-600 hover:underline">Instagram</a>
          </li>
        </ul>
      </div>
    </section>
  </template>
  
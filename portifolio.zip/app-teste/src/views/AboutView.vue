<template>
    <section class="p-8 max-w-3xl mx-auto">
      <h2 class="text-3xl font-bold mb-6">Sobre Mim</h2>
  
      <div class="space-y-4 text-gray-700">
        <p>
          Meu nome é Felipe Meireles, sou estudante de tecnologia com interesse em desenvolvimento web.
        </p>
  
        <p>
          Atualmente, estou aprofundando meus conhecimentos em frameworks modernos como Vue.js, e ferramentas como Tailwind CSS, Vite e Git.
        </p>
  
        <p>
          Busco constantemente aprimorar minhas habilidades através de projetos pessoais sempre que tenho tempo.
        </p>
  
        <h3 class="text-xl font-semibold mt-6">Habilidades</h3>
        <ul class="list-disc list-inside">
          <li>HTML, CSS, JavaScript</li>
          <li>Vue 3</li>
          <li>Tailwind CSS</li>
          <li>Python</li>
          <li>PHP</li>
          <li>C#</li>
          <li>Banco de Dados (PostgreSQL)</li>
        </ul>
  
        <h3 class="text-xl font-semibold mt-6">Formação</h3>
        <ul class="list-disc list-inside">
          <li>Curso em andamento - Análise e Desenvolvimento ded Sistemas</li>
          <li>Cursos online de PostgreSQL</li>
        </ul>
      </div>
    </section>
  </template>
  
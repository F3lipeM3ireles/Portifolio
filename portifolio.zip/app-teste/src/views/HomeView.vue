<template>
    <section class="p-8 max-w-4xl mx-auto space-y-12">
  
      <!-- Apresentação com Foto -->
      <div class="flex flex-col md:flex-row items-center gap-8">
        <img
          src="../assets/img/foto.jpg"
          alt="Foto pessoal"
          class="w-40 h-40 rounded-full object-cover border-4 border-blue-500"
        />
        <div class="text-center md:text-left">
          <h1 class="text-4xl font-bold">Olá, eu sou Felipe Meireles</h1>
          <p class="mt-3 text-gray-700">Desenvolvedor Back-End e Front-End apaixonado em aprender e evoluir.</p>
        </div>
      </div>
  
      <!-- Formação Acadêmica -->
      <div>
        <h2 class="text-2xl font-semibold mb-4">🎓 Formação Acadêmica</h2>
        <ul class="space-y-2 list-disc list-inside text-gray-700">
          <li><strong>Cursando:</strong> Análise e Desenvolvimento de Sistemas – UNIMAR</li>
        </ul>
      </div>
  
      <!-- Experiências Profissionais -->
      <div>
        <h2 class="text-2xl font-semibold mb-4">💼 Experiência Profissional</h2>
        <ul class="space-y-4 text-gray-700">
          <li>
            <strong>Interfocus Tecnologia</strong><br />
            Suporte Especializado de Sistemas – Atual<br />
            <span class="text-sm text-gray-500">Atendimento de clientes e suporte aos serviços disponibilizados pela empresa</span>
          </li>
          <li>
            <strong>A Igreja de Jesus Cristo</strong><br />
            Missionário de Tempo Integral - 2 Anos<br />
            <span class="text-sm text-gray-500">Proselitismo em tempo integral na região de Belém - PA</span>
          </li>

        </ul>
      </div>
  
    </section>
  </template>
  
<template>
    <!-- Footer cor secundária, centralizado e com espaçamento -->
    <footer class="bg-secundario text-white p-4 text-center text-sm mt-10">
      © 2025 Fabricio. Todos os direitos reservados.
    </footer>
  </template>
  
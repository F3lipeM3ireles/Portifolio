<template>
    <!-- navbar fixa no topo com espaçamento interno e cor de fundo -->
    <nav class="bg-primario text-white shadow p-4 flex justify-between">
      <div class="font-bold text-xl">Meu Portfólio</div>
  
      <!-- Links de navegação usando Vue Router -->
      <div class="space-x-4">
        <router-link to="/" class="hover:underline">Home</router-link>
        <router-link to="/sobre" class="hover:underline">Sobre</router-link>
        <router-link to="/contato" class="hover:underline">Contato</router-link>
      </div>
    </nav>
  </template>
  
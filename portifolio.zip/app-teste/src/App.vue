<template>
  <!-- Essa é a div principal. o min-h-screen faz com que ocupe a tela toda, o restante organiza os elementos em colunas -->
  <div class="min-h-screen flex flex-col">
    
    <Navbar />
    <main class="flex-grow"></main>
    <!-- Local onde as views (rotas) são renderizadas dinamicamente com Vue Router -->
    <router-view />

    <Footer />
  </div>
</template>

<script setup>
// Importação dos componentes
import Navbar from './components/Navbar.vue'
import Footer from './components/Footer.vue'
</script>

// Importa a função de criação do roteador e o histórico de navegação
import { createRouter, createWebHistory } from 'vue-router'

// Importa as views para cada rota
import HomeView from '../views/HomeView.vue'
import AboutView from '../views/AboutView.vue'
import ContactView from '../views/ContactView.vue'

// Define as rotas do aplicativo associadas às respectivas views
const routes = [
  { path: '/', name: 'Home', component: HomeView },
  { path: '/sobre', name: 'Sobre', component: AboutView },
  { path: '/contato', name: 'Contato', component: ContactView }
]

// Cria o roteador com histórico do navegador
const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
